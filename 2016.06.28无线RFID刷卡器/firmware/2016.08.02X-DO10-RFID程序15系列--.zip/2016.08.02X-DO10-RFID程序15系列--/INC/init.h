#ifndef _INIT_H_
#define _INIT_H_


void IO_Init(void);
void Start_Init(void);


#endif