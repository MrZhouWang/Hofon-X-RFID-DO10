#ifndef _DELAY_H_
#define _DELAY_H_




void Delay1Ms(); 
void DelayMs(UINT16 usDelay);

#endif


